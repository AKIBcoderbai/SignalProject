import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY

export const supabase = url && key ? createClient(url, key) : null
export const setupError = supabase ? '' : 'Set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY in your React .env file, then restart Vite.'
